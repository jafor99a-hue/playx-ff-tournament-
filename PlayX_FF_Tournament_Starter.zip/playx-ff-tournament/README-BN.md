# PlayX FF Tournament — Starter Website

এটি PlayX FF Tournament-এর responsive frontend starter। মোবাইল ও কম্পিউটার দুই জায়গাতেই ব্যবহার করা যায়।

## এখন কী কাজ করছে?
- Responsive homepage এবং mobile menu
- Demo tournament cards
- Demo results table
- Login/Register modal UI
- Join button feedback
- Admin panel preview

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি এখনো **frontend demo**, সম্পূর্ণ production website নয়। Login/Register button এখন সত্যিকারের account তৈরি করে না; Tournament Join ডেটাবেসে সংরক্ষণ করে না; Room ID বা admin actions live নয়। নিরাপত্তার জন্য backend ও database security rules সেটআপ করতে হবে। Firebase config ছাড়া authentication চালু হবে না।

## ফ্রি হোস্টিং: GitHub Pages
1. GitHub-এ account তৈরি করো।
2. নতুন repository বানাও, নাম দাও `playx-ff-tournament`।
3. এই ZIP-এর `index.html`, `style.css`, `app.js` ও `README-BN.md` ফাইল repository-তে upload করো।
4. Repository → **Settings** → **Pages**-এ যাও।
5. Build and deployment-এ `Deploy from a branch` নির্বাচন করো।
6. Branch হিসেবে `main`, folder হিসেবে `/ (root)` নির্বাচন করে Save করো।
7. কিছুক্ষণ পর GitHub Pages-এর দেওয়া URL-এ সাইটটি দেখবে।

## বাস্তব Login/Registration, Tournament Join ও Admin Panel কীভাবে যোগ হবে
সবচেয়ে সহজ ফ্রি-টিয়ার পথ হলো Firebase:
1. Firebase Console-এ project তৈরি করো।
2. Authentication → Sign-in method-এ Email/Password চালু করো।
3. Firestore Database তৈরি করো।
4. Web app যোগ করে Firebase config সংগ্রহ করো।
5. Firebase Authentication SDK দিয়ে register/login যুক্ত করো।
6. `tournaments`, `registrations`, `results`, `users` collection তৈরি করো।
7. Admin role কেবল trusted server/Admin SDK বা নিরাপদ custom claims দিয়ে নির্ধারণ করো। শুধু browser-side `isAdmin` check নিরাপদ নয়।
8. Firestore Security Rules এমনভাবে লেখো যেন সাধারণ user শুধু নিজের registration পড়তে/লিখতে পারে এবং শুধু অনুমোদিত admin tournament, room details ও results পরিবর্তন করতে পারে।
9. Room ID/Password কেবল অনুমোদিত tournament participant-দের দেখানোর নিয়ম বানাও।
10. Test account দিয়ে login, registration, join, results এবং admin permissions পরীক্ষা করো।

## প্রস্তাবিত ডেটা স্ট্রাকচার
- `users/{uid}`: displayName, email, role (role server-controlled হবে)
- `tournaments/{tournamentId}`: title, mode, map, entryFee, prizePool, startAt, status
- `registrations/{registrationId}`: tournamentId, uid, inGameName, freeFireUid, teamName, status
- `results/{resultId}`: tournamentId, placements, points, publishedAt
- `roomDetails/{tournamentId}`: roomId, password, visibleToParticipants

## নিরাপত্তা ও বিশ্বাসযোগ্যতা
- কখনো Firebase Admin SDK private key বা server secret frontend-এ রাখবে না।
- Admin email-এর তালিকা শুধু JavaScript ফাইলে রেখে নিরাপত্তা তৈরি করা যাবে না।
- যদি entry fee/prize ব্যবহার করো, আগে স্থানীয় আইন, প্ল্যাটফর্মের নিয়ম ও পেমেন্ট সংক্রান্ত বাধ্যবাধকতা যাচাই করো। এই starter-এ সব entry fee `Free` রাখা হয়েছে।
- Garena/Free Fire-এর official website বলে পরিচয় দেবে না; fan/community tournament platform হিসেবে স্পষ্ট রাখো।

## ফাইল
- `index.html`: page structure
- `style.css`: visual design and responsive layout
- `app.js`: demo data and UI interactions
