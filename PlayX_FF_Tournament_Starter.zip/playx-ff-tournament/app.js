const tournaments = [
  {id:"solo",name:"Solo Clash",mode:"SOLO",players:"1 Player",map:"Bermuda",entry:"Free",prize:"৳ 500",date:"তারিখ শিগগিরই জানানো হবে",status:"Registration open"},
  {id:"duo",name:"Duo Battle",mode:"DUO",players:"2 Players",map:"Purgatory",entry:"Free",prize:"৳ 1,000",date:"তারিখ শিগগিরই জানানো হবে",status:"Registration open"},
  {id:"squad",name:"Squad War",mode:"SQUAD",players:"4 Players",map:"Bermuda",entry:"Free",prize:"৳ 2,000",date:"তারিখ শিগগিরই জানানো হবে",status:"Coming soon"}
];
const results = [
  {name:"Solo Clash #001",winner:"ফলাফল প্রকাশের অপেক্ষায়",status:"Pending"},
  {name:"Duo Battle #001",winner:"ফলাফল প্রকাশের অপেক্ষায়",status:"Pending"}
];
const list = document.querySelector("#tournamentList");
list.innerHTML = tournaments.map(t => `<article class="t-card"><span class="tag">${t.mode}</span><h3>${t.name}</h3><p>🎮 ${t.players} · 🗺️ ${t.map}</p><p>🗓️ ${t.date}</p><p>${t.status}</p><div class="card-foot"><div><small class="muted">Prize pool</small><div class="prize">${t.prize}</div></div><button class="btn join-btn" data-id="${t.id}">Join Now</button></div></article>`).join("");
document.querySelector("#resultsList").innerHTML = results.map(r => `<tr><td>${r.name}</td><td>${r.winner}</td><td class="status">${r.status}</td></tr>`).join("");
document.querySelector("#countT").textContent = tournaments.length;
document.querySelector("#countR").textContent = results.length;

const nav = document.querySelector("#nav");
document.querySelector("#menuBtn").addEventListener("click", () => nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));

const backdrop = document.querySelector("#modalBackdrop");
const title = document.querySelector("#modalTitle");
const nameLabel = document.querySelector("#nameLabel");
const submit = document.querySelector("#accountSubmit");
const formNote = document.querySelector("#formNote");
let mode = "login";
function openAccount(nextMode) {
  mode = nextMode;
  title.textContent = mode === "login" ? "Login" : "Create Account";
  submit.textContent = mode === "login" ? "Login" : "Register";
  nameLabel.hidden = mode === "login";
  document.querySelector("#fullName").required = mode === "register";
  formNote.textContent = "এখন এটি UI demo; Firebase যুক্ত না করলে অ্যাকাউন্ট তৈরি হবে না।";
  backdrop.hidden = false;
}
document.querySelector("#loginOpen").addEventListener("click", () => openAccount("login"));
document.querySelector("#registerOpen").addEventListener("click", () => openAccount("register"));
document.querySelector("#modalClose").addEventListener("click", () => backdrop.hidden = true);
backdrop.addEventListener("click", e => { if(e.target === backdrop) backdrop.hidden = true; });
document.querySelector("#accountForm").addEventListener("submit", e => {
  e.preventDefault();
  showToast("এটি শুধু ডিজাইন ডেমো। Login/Registration চালু করতে Firebase সেটআপ দরকার।");
});
document.querySelectorAll(".join-btn").forEach(btn => btn.addEventListener("click", () => {
  showToast("Join করার আগে Login/Registration ও Tournament backend সেটআপ করতে হবে।");
}));
document.querySelector("#adminInfo").addEventListener("click", () => {
  showToast("Checklist: Firebase Auth, Firestore database, admin role, security rules, tournament CRUD, results, room details.");
});
let toastTimer;
function showToast(message) {
  const toast = document.querySelector("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3600);
}
